<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../lib/stile.css">
<link rel="stylesheet" href="lib/stile.css">

